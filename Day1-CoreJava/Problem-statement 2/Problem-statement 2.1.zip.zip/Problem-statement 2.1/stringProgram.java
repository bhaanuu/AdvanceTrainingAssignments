package com.programs;
import java.util.Scanner;
 
public class stringProgram
{
   public static void main(String args[])
   {
      String str, rev = "";
      Scanner sc = new Scanner(System.in);
 
      System.out.println("Enter a string:");
      str = sc.nextLine();
      String strUpper = str.toUpperCase();
 
      int length = str.length();
      
      System.out.println("Length of the string :" + length);
 
      for ( int i = length - 1; i >= 0; i-- )
         rev = rev + str.charAt(i);
 
      if (str.equals(rev))
         System.out.println(strUpper+" is a palindrome");
      else
         System.out.println(strUpper+" is not a palindrome");
 
   }
}