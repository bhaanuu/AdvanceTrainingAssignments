package com.program;

public class TestRectangle {

	public static void main(String[] args) {

	        rectangleProgram obj1 = new rectangleProgram();
	        obj1.input();
	        obj1.calculate();
	        obj1.display();
	        System.out.println();
	        rectangleProgram obj2 = new rectangleProgram();
	        obj2.input();
	        obj2.calculate();
	        obj2.display();
	        System.out.println();
	        rectangleProgram obj3 = new rectangleProgram();
	        obj3.input();
	        obj3.calculate();
	        obj3.display();
	        System.out.println();
	        rectangleProgram obj4 = new rectangleProgram();
	        obj4.input();
	        obj4.calculate();
	        obj4.display();
	        System.out.println();
	        rectangleProgram obj5 = new rectangleProgram();
	        obj5.input();
	        obj5.calculate();
	        obj5.display();
	    }
	}


