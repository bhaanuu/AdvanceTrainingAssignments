package com.program;

import java.util.Scanner;

class rectangleProgram {
    int length; 
    int breadth; 
    int area; 
   
    public rectangleProgram()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = sc.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = sc.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
       
    }

    
}