package com.programs;

public class stringHandling {

		public static void main(String[] args) {
			
		
		String str= "JAVA is Simple";
		
		System.out.println(str.toUpperCase()); //UpperCase
		
		System.out.println(str.toLowerCase()); //LowerCase
		
		
		String[] words=str.split("\\s");	//1st words of letter (J i S)
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		String[] words0 = str.split(" ");
        StringBuilder reverseString = new StringBuilder();

        for (int i = words.length - 1; i >= 0; i--) {
            reverseString.append(words0[i]).append(" ");
        }
        System.out.println(reverseString);
        
        
		
		String[] words1=str.split("\\s");   //AVAJ si elpmiS
		String reverseWord="";
		for(String w1:words)
		{
			StringBuilder str1=new StringBuilder(w1);
			str1.reverse();
			reverseWord+=str1.toString()+" ";

		}
		System.out.println(reverseWord);
		
		
		System.out.println("length of string " + str.length());


		}

		
		

		
		
	
}