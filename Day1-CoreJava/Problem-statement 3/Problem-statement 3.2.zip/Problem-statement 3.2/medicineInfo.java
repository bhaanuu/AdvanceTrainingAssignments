package com.programs2;


public class medicineInfo{
public void displayLabel(){
System.out.println("Company : Dr Reddys Lboratories");
System.out.println("Address : Hyderabad");
}
}
class Tablet extends medicineInfo{
	 
public void displayLabel(){
System.out.println("store in a cool dry place");
}
}class Syrup extends medicineInfo{

public void displayLabel(){
System.out.println("Consumption as directed by thephysician");
}
}
class Ointment extends medicineInfo{
public void displayLabel(){
System.out.println("for external use only");
}
}