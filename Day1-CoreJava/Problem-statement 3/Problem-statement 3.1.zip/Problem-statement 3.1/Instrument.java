package com.programs;


public abstract class Instrument {
	public abstract void play();
}
